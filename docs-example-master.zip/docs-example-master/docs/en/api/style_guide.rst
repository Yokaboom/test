.. role:: hidden
    :class: hidden-section

.. role:: hidden
    :class: hidden-section

docs_example.style_guide
===================================

.. contents:: docs_example.style_guide
   :depth: 2
   :local:
   :backlinks: top

.. currentmodule:: docs_example.style_guide

.. autosummary::
   :toctree: generated
   :nosignatures:
   :template: classtemplate.rst

    ExampleClass
    example_generator
    module_level_function
