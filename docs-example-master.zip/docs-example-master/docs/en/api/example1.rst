.. role:: hidden
    :class: hidden-section

docs_example.example1
===================================

.. currentmodule:: docs_example.example1

.. autofunction:: say_hello
