.. role:: hidden
    :class: hidden-section

docs_example.example2
===================================

.. currentmodule:: docs_example.example2

.. autofunction:: say_hi
