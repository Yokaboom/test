example1
--------
.. automodule:: docs_example.example1
    :members:

example2
--------
.. automodule:: docs_example.example2
    :members:

style guide
----------------
.. automodule:: docs_example.style_guide
    :members:
