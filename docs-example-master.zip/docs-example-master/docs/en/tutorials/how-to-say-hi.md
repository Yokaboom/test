## How to say hi

```python
>>> from docs_example.example1 import say_hi
>>> say_hi()
hi
```
