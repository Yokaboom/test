## How to say hello

```python
>>> from docs_example.example1 import say_hello
>>> say_hello()
hello
```
